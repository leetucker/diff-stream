Focused Stata BJS precision validation: 3 cases, 48 fits

Extract into a new folder and cd to the folder containing RUN_STATA.do.
Run: do RUN_STATA.do
Return the entire results folder to benchmarks/results/stata_bjs_precision/.
Keep the baseline and extended results unchanged. Use the same installed
did_imputation/reghdfe/ftools versions; no package updates are needed.

The only estimator-setting change is set type double after clear all.
Importing inputs as double does not control implicit temporary gen types
inside the authors' command. This rerun checks whether those temporaries
explain estimate differences above 1e-7 in the extended results.
All specifications, weights, tolerances and data come from the original
hashed bundle. No installed command is edited. No Python or R needed here.

Cases: balanced_w1_a2, complete_w1_a2, mpdta_w0_a0, each with the same
four averaging schemes, plugin/leaveout, and dynamic/simple aggregation.
Expected: 48 successful status rows and 154 CSVs including diagnostics.
Return failures and logs too; the script continues after failed fits.
