do validate_bjs_extended.do
