run_case, name("balanced_w1_a2") input("balanced.csv") anticipation(2) pretrends(3) weighted(1)
run_case, name("complete_w1_a2") input("complete.csv") anticipation(2) pretrends(3) weighted(1)
run_case, name("mpdta_w0_a0") input("mpdta.csv") anticipation(0) pretrends(1) weighted(0)
