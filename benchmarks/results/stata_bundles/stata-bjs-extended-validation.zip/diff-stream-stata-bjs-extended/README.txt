BJS follow-up validation (11 cases, 176 did_imputation fits)

1. Extract the whole ZIP to a new writable folder. Do not reuse old results.
2. In Stata, cd to that folder (the one containing RUN_STATA.do).
3. Ensure did_imputation, reghdfe and ftools are installed. Use the same versions
   as the first bundle if possible; no package updates are required by this bundle.
4. Run: do RUN_STATA.do
5. Return the entire results folder, including status.csv and validation.log.
   Place it at benchmarks/results/stata_bjs_extended in the Python checkout.

No Python, R or original repository is needed on the Stata machine.
The log should end with BJS EXTENDED VALIDATION FINISHED. Fits that fail are
recorded in status.csv and the script continues; return failures too. Do not
manually remove terms, change tolerances, or rerun individual outputs in place.

Cases cover weights, balanced/native unbalanced/complete panels, anticipation,
future-treated controls, and the public mpdta dataset. Each case crosses four
smart averages, plugin/leaveout inference, and dynamic/simple aggregation.
Simple ATT excludes anticipation rows via wtr(actual_post). Clean placebos
retain actual future cohort labels. CSVs import as double; exports retain
17 significant digits. Authors' placebo SSC inputs and F tests are recorded.
Python comparison divides only placebo covariance by the recorded SSC;
post covariance is CRV0. Post/placebo cross covariance has no Python counterpart.

Input origins: anticipation_panel.csv is the checkout's deterministic synthetic
fixture; mpdta.csv is frozen from R did::mpdta (see docs/mpdta_replication.md).
MANIFEST.json records cases, source hashes, and transferred file hashes.
This bundle has Python preflight checks; its Stata execution remains external.
