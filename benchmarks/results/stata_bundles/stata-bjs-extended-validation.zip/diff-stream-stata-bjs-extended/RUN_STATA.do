* Set Stata working directory to this extracted folder, then run this file.
do validate_bjs_extended.do
