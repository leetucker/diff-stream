BJS STATA VALIDATION: TRANSFER AND RETURN

Scope: balanced unweighted reference panel, no anticipation, dynamic/simple
aggregates, all four avgeffectsby settings, plugin/leaveout. This checks the
authors' Stata implementation, including FULL covariance. It does not yet cover
weighted/unbalanced panels, anticipation, clean placebos or CS/SA Stata outputs.
The do-file has not been executed in Stata on the development machine.

ON THE STATA MACHINE
1. Unzip this archive, retaining its directory structure.
2. In Stata, install these packages if absent (internet needed for installation):
      ssc install ftools
      ssc install reghdfe
      ssc install did_imputation
   Existing installations may be used; environment.log records their versions.
   If offline, install the packages and their dependencies before disconnecting,
   or obtain a complete working Stata ado installation from your usual source.
3. Set the Stata working directory to the unpacked bundle root, e.g.:
      cd "C:/work/diff-stream-stata-bjs"
      do RUN_STATA.do
   On Linux/macOS the folder path differs; the same do-file works.
   A batch run from that directory can use: stata-mp -b do RUN_STATA.do
   Substitute your actual Stata executable name.
4. Verify validation.log reaches the end without an error. Retain all files,
   including logs if a run fails. Do not change minn(0), clustering, tolerances,
   averaging settings, input data, or CSV names to force agreement.

RETURN TO THE DEVELOPMENT MACHINE
Return the ENTIRE benchmarks/results/stata_bjs folder, including:
- 16 coefficient CSV files and 16 covariance CSV files
- validation.log and environment.log
Copy it to the same relative path in the diff-stream checkout, then run:
  STREAM_LIMITS_MAX_THREADS=2 MPLCONFIGDIR=/tmp/diff-stream-mpl .venv/bin/python -m pytest -q tests/test_reference.py::test_stata_bjs_bundle_when_available
Or retain the folder anywhere and set DIFF_STATA_BJS to its absolute path:
  DIFF_STATA_BJS=/path/to/stata_bjs STREAM_LIMITS_MAX_THREADS=2 .venv/bin/python -m pytest -q tests/test_reference.py::test_stata_bjs_bundle_when_available
The Python comparison happens on the DEVELOPMENT machine; no Python is needed
on the Stata machine. Sample choices and inference conventions must match.

PROVENANCE
MANIFEST.json contains hashes of the exact input and scripts shipped here.
Keep a copy of the bundle and manifest with the returned results.
