* First cd to the unpacked bundle root. No Python or R is required here.
clear all
set more off
capture mkdir benchmarks
capture mkdir benchmarks/results
capture mkdir benchmarks/results/stata_bjs
capture log close _all
log using benchmarks/results/stata_bjs/environment.log, text replace
about
which did_imputation
which reghdfe
which ftools
log close
do benchmarks/external/validate_bjs.do
